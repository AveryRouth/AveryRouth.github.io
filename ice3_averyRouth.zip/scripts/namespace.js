"use strict";

let core ={};