"use strict";

let core;